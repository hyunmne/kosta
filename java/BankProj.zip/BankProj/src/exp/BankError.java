package exp;

public enum BankError {
	NO_ID, NO_SENDID, NO_RECVID, DOUBLE_ID, OVERDRAWN, MENU, DEPOSIT
}
